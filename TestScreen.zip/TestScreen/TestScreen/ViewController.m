//
//  ViewController.m
//  TestScreen
//
//  Created by 董家祎 on 2023/3/1.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (IBAction)buttonAction:(id)sender {
    
   
        NSArray *scenes = [[[UIApplication sharedApplication] connectedScenes] allObjects];
        UIWindowScene *scene = [scenes firstObject];
        UIWindowSceneGeometryPreferencesIOS *geometryPerferencesIOS = [[UIWindowSceneGeometryPreferencesIOS alloc] initWithInterfaceOrientations: UIInterfaceOrientationMaskLandscapeLeft];

        [scene requestGeometryUpdateWithPreferences:geometryPerferencesIOS errorHandler:^(NSError * _Nonnull error) {
            NSLog(@"kingiol error: %@", error);
           
        }];
       
 

   
}
- (UIInterfaceOrientation)preferredInterfaceOrientationForPresentation{
    return UIInterfaceOrientationLandscapeLeft;
}
@end
