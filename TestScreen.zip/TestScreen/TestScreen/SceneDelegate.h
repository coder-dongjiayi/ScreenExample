//
//  SceneDelegate.h
//  TestScreen
//
//  Created by 董家祎 on 2023/3/1.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

