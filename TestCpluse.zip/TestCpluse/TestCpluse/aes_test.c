//
//  aes_test.c
//  TestCpluse
//
//  Created by 董家祎 on 2022/6/1.
//

#include "aes_test.h"
//void test(){
//    struct AES_ctx ctx;
//
//
//    uint8_t key[] = "mxloggermxlogger";
//    uint8_t iv[]  = "bbbbbbbbbbbbbbbb";
//    std::string myString = "{\"n\":\"name\",\"a\":\"net\",\"m\":\"第0条数据\",\"imt\":true,\"tid\":761553,\"p\":1,\"tsp\":\"1653982799.474813\"}";
//
//    char* str = myString.data();
//    int dlen = (int)strlen(str);
//
//    void* ptr = str;
//
//
//
//    int dlenu = dlen;
//    if (dlen % 16) {
//        dlenu += 16 - (dlen % 16);
//    }
//
//    uint8_t hexarray[dlenu];
//    memset(hexarray, 0, dlenu);
//    for (int i=0;i<dlen;i++) {
//        hexarray[i] = (uint8_t)str[i];
//    }
//
//    printf("\n raw buffer \n");
//    for (int i = 0; i < dlenu; ++i) {
//        printf("%.2x", hexarray[i]);
//    }
//
//    AES_init_ctx_iv(&ctx, key, iv);
//    AES_CBC_encrypt_buffer(&ctx, hexarray, dlenu);
//
//    printf("\n Encrypted buffer\n");
//
//    printf("%ld\n",strlen((char*)hexarray));
//
//    for (int i = 0; i < dlenu; ++i) {
//        printf("%.2x", hexarray[i]);
//    }
//
//    printf("\n Decrypted buffer\n");
//
//    AES_init_ctx_iv(&ctx, key, iv);
//    AES_CBC_decrypt_buffer(&ctx, (uint8_t*)hexarray, dlenu);
//
//    printf("%s",(char*)hexarray);
//
//
//    printf("\n");
//}
