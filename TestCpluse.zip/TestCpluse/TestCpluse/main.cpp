#include <stdio.h>
#include <stdlib.h>
#include <string>

#include <stdexcept>
#include <iostream>
#include <iomanip>
#include <sstream>
#include <iostream>     // std::cout
#include <fstream>
#include <cstring>
#include <zlib.h>
#include <sstream>
#include "mx_json.h"

template <class charT>
std::basic_string<charT>
gen_title(std::basic_string<charT> const& tm_text, charT sep)
{
    constexpr auto wide = 79U;

    // top
    std::basic_ostringstream<charT> oss;
    oss << std::endl;
    for (size_t i = 0; i != wide; ++i)
    {
        oss << sep;
    }
    oss << std::endl;

    // center
    oss << sep << std::setw(wide-1) << sep << std::endl;
    if (tm_text.size() <= wide / 2)
    {
        auto const text_pos = (wide - 2 + tm_text.size()) / 2;
        auto const sep_pos = (wide - 2 - tm_text.size()) / 2 + 1;
        oss << sep
            << std::setw(text_pos) << tm_text
            << std::setw(sep_pos) << sep << std::endl;

        oss << sep << std::setw(wide - 1) << sep << std::endl;
    }

    // bottom
    for (size_t i = 0; i != wide; ++i)
    {
        oss << sep;
    }
    oss << std::endl;
    return oss.str();
}

int main() {
  
   std::string str =  gen_title<std::string::value_type>("Welcome to MXLogger",'*');
    printf("%s",str.data());
    return 0;
}
